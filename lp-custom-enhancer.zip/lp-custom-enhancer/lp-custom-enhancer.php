<?php
/**
 * Plugin Name: LearnPress Custom Enhancer
 * Description: Thêm thanh thông báo, hiển thị thống kê khóa học bằng shortcode và tùy biến CSS.
 * Version: 1.0
 * Author: Trần Quang Minh
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class LP_Custom_Enhancer {

    public function __construct() {
        // Yêu cầu 1: Hiển thị thanh thông báo
        add_action( 'wp_footer', array( $this, 'show_notification_bar' ) );
        
        // Yêu cầu 2: Đăng ký Shortcode [lp_course_info id="xxx"]
        add_shortcode( 'lp_course_info', array( $this, 'render_course_info_shortcode' ) );
        
        // Yêu cầu 3: Chèn Custom CSS đổi màu nút
        add_action( 'wp_head', array( $this, 'custom_button_style' ) );
    }

    /**
     * Yêu cầu 1: Thanh thông báo "Học viên mới"
     */
    public function show_notification_bar() {
        // Chỉ hiển thị trên trang chi tiết khóa học
        if ( ! is_singular( 'lp_course' ) ) {
            return;
        }

        if ( is_user_logged_in() ) {
            $current_user = wp_get_current_user();
            $message = "Chào " . esc_html( $current_user->display_name ) . ", bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?";
        } else {
            $message = "Đăng nhập để lưu tiến độ học tập!";
        }

        // HTML & CSS trực tiếp cho thanh thông báo (Sticky ở trên cùng)
        echo '<div style="background-color: #27ae60; color: #fff; text-align: center; padding: 12px; position: fixed; top: 0; left: 0; width: 100%; z-index: 99999; font-weight: bold; font-size: 16px; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">' . $message . '</div>';
        // Thêm khoảng trống ở body để không bị thanh thông báo che mất menu
        echo '<style>body { padding-top: 45px; }</style>';
    }

    /**
     * Yêu cầu 2: Hàm xử lý Shortcode thống kê chi tiết khóa học
     */
    public function render_course_info_shortcode( $atts ) {
        // Kiểm tra xem LearnPress đã được cài đặt chưa
        if ( ! class_exists( 'LP_Course' ) ) {
            return '<p>Vui lòng cài đặt và kích hoạt LearnPress.</p>';
        }

        // Lấy ID khóa học từ shortcode
        $atts = shortcode_atts( array( 'id' => 0 ), $atts );
        $course_id = intval( $atts['id'] );

        if ( ! $course_id ) {
            return '<p>Vui lòng cung cấp ID khóa học. Ví dụ: [lp_course_info id="123"]</p>';
        }

        // Lấy đối tượng khóa học
        $course = learn_press_get_course( $course_id );
        if ( ! $course ) {
            return '<p>Không tìm thấy khóa học với ID: ' . $course_id . '</p>';
        }

        // 1. Số lượng bài học (Lessons)
        $lessons_count = $course->count_items( 'lp_lesson' );

        // 2. Tổng thời gian dự kiến (Duration)
        $duration = $course->get_duration();

        // 3. Trạng thái của người dùng
        $user = learn_press_get_current_user();
        $status_text = 'Chưa đăng ký';
        
        if ( $user && ! $user->is_guest() ) {
            if ( $user->has_finished_course( $course_id ) ) {
                $status_text = 'Đã hoàn thành';
            } elseif ( $user->has_enrolled_course( $course_id ) ) {
                $status_text = 'Đã đăng ký (Đang học)';
            }
        }

        // Hiển thị giao diện Shortcode
        ob_start();
        ?>
        <div style="background: #fdfaf6; border: 2px dashed #e67e22; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h4 style="margin-top: 0; color: #e67e22;">Thống kê chi tiết khóa học</h4>
            <ul style="list-style-type: none; padding-left: 0; font-size: 15px;">
                <li>📚 <strong>Số bài học:</strong> <?php echo $lessons_count; ?> bài</li>
                <li>⏱️ <strong>Thời lượng dự kiến:</strong> <?php echo $duration; ?></li>
                <li>🎓 <strong>Trạng thái của bạn:</strong> <span style="color: #2980b9; font-weight: bold;"><?php echo $status_text; ?></span></li>
            </ul>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Yêu cầu 3: Tùy biến Style (Đổi nút sang màu Cam)
     */
    public function custom_button_style() {
        ?>
        <style>
            /* Nhắm mục tiêu vào các nút Enroll và Finish của LearnPress */
            .learn-press .lp-button,
            .learn-press button[type="submit"].lp-button,
            .learn-press .btn-enroll,
            form[name="course-enroll"] button,
            form[name="course-complete"] button {
                background-color: #e67e22 !important; /* Màu Cam */
                border-color: #d35400 !important;
                color: #ffffff !important;
                border-radius: 5px !important;
                transition: 0.3s !important;
            }
            /* Hiệu ứng khi di chuột qua nút */
            .learn-press .lp-button:hover,
            form[name="course-enroll"] button:hover,
            form[name="course-complete"] button:hover {
                background-color: #d35400 !important; /* Màu Cam đậm hơn */
            }
        </style>
        <?php
    }
}

// Khởi tạo Plugin
new LP_Custom_Enhancer();